const danhSachGiaoDich = [
  {
    id: 1102,
    khachHang: "Võ Hoài An",
    nhanVien: "Mai Thục Anh",
    soTien: 250000,
    ngayMua: "2024-06-06T09:00"
  },
  {
    id: 1199,
    khachHang: "Hoàng Thị Thắng",
    nhanVien: "Nguyễn Văn Hồng",
    soTien: 600000,
    ngayMua: "2024-06-06T09:03"
  },
  {
    id: 1239,
    khachHang: "Nguyễn Huy Quang",
    nhanVien: "Nguyễn Văn Hồng",
    soTien: 934000,
    ngayMua: "2024-06-06T09:10"
  },
  {
    id: 1677,
    khachHang: "Huỳnh Văn Nam",
    nhanVien: "Mai Thục Anh",
    soTien: 150000,
    ngayMua: "2024-06-06T09:20"
  },
  {
    id: 1996,
    khachHang: "Nguyễn Hữu Minh",
    nhanVien: "Mai Thục Anh",
    soTien: 354000,
    ngayMua: "2024-06-06T09:24"
  }
];
